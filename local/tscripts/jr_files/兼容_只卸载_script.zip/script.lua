dofile("/data/local/tmp/c/engine/BasicEngine.lua")
-------------------------------------------------------------------
-------------------------------------------------------------------
Businesses = "appж��"
Edition = "1.0.0"

JRAPPTEST_uninstall = "ж��"
