dofile("/data/local/tmp/c/engine/BasicEngine.lua")
-------------------------------------------------------------------
-------------------------------------------------------------------
Businesses = "app��װ"
Edition = "1.0.0"

JRAPPTEST_install = "��װ"
JRAPPTEST_uninstall = "ж��"
