# -*- coding: utf-8 -*-
import os

msg = "hello"
print("zsg000")
print(msg)
end = "---end---"
print(end)