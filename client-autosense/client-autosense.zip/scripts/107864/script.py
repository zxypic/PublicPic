# -*- coding: utf-8 -*-

msg = "hello"
print("zsg0000")
print(msg)
end = "---end---"
print(end)
print("中国")