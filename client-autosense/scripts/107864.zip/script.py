# -*- coding: utf-8 -*-

msg = "hello"
print("zsg")
print(msg)
end = "---end---"
print(end)
print("中国")