#encoding:utf-8
'''
@author: 3020
'''
import os
import time

def execCmd():
    """
    """
    os.system("dir > E://resut01.txet")
    time.sleep(2)
	print("execute end")
    
    

if __name__ == '__main__':
    execCmd()
